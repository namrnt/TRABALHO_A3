//Faça um Programa que mostre a mensagem "Alo mundo" na tela.

public class questao1 {
    public static void main(String[] args) {
        System.out.println("Alo mundo");

    }
}
